package com.example.connormonson.assignment2;

public class User {

    private String entry1;
    private String entry2;
    private String entry3;

    public User(String fEntry1, String fEntry2, String fEntry3){
        entry1 = fEntry1;
        entry2 = fEntry2;
        entry3 = fEntry3;
    }

    public String getEntry1() {
        return entry1;
    }



    public String getEntry2() {
        return entry2;
    }



    public String getEntry3() {
        return entry3;
    }

}
